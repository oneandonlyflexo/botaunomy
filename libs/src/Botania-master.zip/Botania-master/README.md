![](web/img/logo.png)  
Welcome to the Botania repository.  

Botania is a [Minecraft](https://minecraft.net/) mod based on adding natural magic to the game. It's inspired by other magic mods, such as [Thaumcraft](http://www.minecraftforum.net/topic/2011841-) or [Blood Magic](http://www.minecraftforum.net/topic/1899223-).  

The current iteration of Botania for 1.10 is made possible thanks to the massive help by the part of williewillus, who ported the mod through 1.8, 1.9 and 1.10, so go buy him a beer or something, I dunno, he's pretty cool.

Botania is licensed under the [Botania License](http://botaniamod.net/license.php)
