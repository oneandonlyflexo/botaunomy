package vazkii.botania.client.model;

public interface IPylonModel {
	void renderRing();

	void renderCrystal();
}
