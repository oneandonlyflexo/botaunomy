@API(owner = "Botania", apiVersion = "88", provides = "BotaniaAPI")
package vazkii.botania.api;
import net.minecraftforge.fml.common.API;

