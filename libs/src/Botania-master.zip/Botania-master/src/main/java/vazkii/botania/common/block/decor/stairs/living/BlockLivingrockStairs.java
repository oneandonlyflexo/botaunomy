package vazkii.botania.common.block.decor.stairs.living;

import vazkii.botania.common.block.ModBlocks;
import vazkii.botania.common.block.decor.stairs.BlockLivingStairs;

public class BlockLivingrockStairs extends BlockLivingStairs {

	public BlockLivingrockStairs() {
		super(ModBlocks.livingrock.getDefaultState());
	}

}
