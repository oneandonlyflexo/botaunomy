Forge version: 
Botania version: 
Link to crash log: (please use a paste site such as [gist](https://gist.github.com/), do not attach the .txt or paste the log inline)

Steps to reproduce:
1. 

What I expected to happen:

What happened instead:
